<?php
// SAFE DEMO: never send or store real PINs/OTPs.
// Put your Telegram bot token and chat ID in the environment on your server.
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$phone = preg_replace('/\D+/', '', $input['phone'] ?? '');
$masked = $phone ? substr($phone,0,3) . '****' . substr($phone,-2) : '07XXXXX';

$token = getenv('TELEGRAM_BOT_TOKEN');
$chat = getenv('TELEGRAM_CHAT_ID');

if (!$token || !$chat) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'Telegram environment variables are not configured.']);
  exit;
}

$text = "🔐 DEMO VERIFICATION\n\n"
      . "Phone: {$masked}\n"
      . "Event: Demo PIN step completed\n"
      . "PIN: [not transmitted]\n\n"
      . "🟡 Status: Pending";

$keyboard = [
  'inline_keyboard' => [
    [['text'=>'✅ Mark Demo Verified','callback_data'=>'demo_verified']],
    [['text'=>'❌ Mark Demo Rejected','callback_data'=>'demo_rejected']],
    [['text'=>'⏱ Extend Demo Time','callback_data'=>'demo_extend']]
  ]
];

$url = "https://api.telegram.org/bot" . rawurlencode($token) . "/sendMessage";
$post = http_build_query([
  'chat_id'=>$chat,
  'text'=>$text,
  'reply_markup'=>json_encode($keyboard)
]);

$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_POST=>true,
  CURLOPT_POSTFIELDS=>$post,
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_TIMEOUT=>15
]);
$result = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

if ($err) {
  http_response_code(502);
  echo json_encode(['ok'=>false,'error'=>$err]);
  exit;
}
echo json_encode(['ok'=>true]);
?>